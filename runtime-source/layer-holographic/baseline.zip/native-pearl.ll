;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; TEXCOORD                 0   xyzw        0     NONE   float   xyzw
; TEXCOORD                 1   xyzw        1     NONE   float   xyzw
; TEXCOORD                 2   xyzw        2     NONE   float   xyzw
; TEXCOORD                 3   xyzw        3     NONE   float   xyzw
; SV_Position              0   xyzw        4      POS   float       
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader debug name: f1d6671e0b5f28dee79c8d0912df847d.pdb
; shader hash: f1d6671e0b5f28dee79c8d0912df847d
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 5
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 5
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: ShaderDomain_Ps
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; TEXCOORD                 0                 linear       
; TEXCOORD                 1                 linear       
; TEXCOORD                 2                 linear       
; TEXCOORD                 3                 linear       
; SV_Position              0          noperspective       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
; cbuffer 
; {
;
;   [80 x i8] (type annotation not present)
;
; }
;
; cbuffer 
; {
;
;   [4552 x i8] (type annotation not present)
;
; }
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
;                                   cbuffer      NA          NA     CB0            cb1     1
;                                   cbuffer      NA          NA     CB1            cb4     1
;                                   sampler      NA          NA      S0             s0     1
;                                   texture     f32     2darray      T0            t32     1
;                                   texture     f32          2d      T1             t0     1
;                                   texture     f32          2d      T2            t33     1
;                                   texture     f32          2d      T3             t1     1
;                                   texture     f32          2d      T4             t2     1
;                                   texture     f32          2d      T5            t35     1
;                                   texture     f32          2d      T6            t36     1
;
;
; ViewId state:
;
; Number of inputs: 20, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }
;   output 1 depends on inputs: { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }
;   output 2 depends on inputs: { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.CBufRet.f32 = type { float, float, float, float }
%dx.types.CBufRet.i32 = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2DArray<vector<float, 4> >" = type { <4 x float>, %"class.Texture2DArray<vector<float, 4> >::mips_type" }
%"class.Texture2DArray<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%PerObjectImmutableConstants = type { <3 x float>, i32, <3 x float>, float, <3 x float>, i32, <3 x float>, float, <2 x float>, float, i32 }
%hostlayout.PerPassConstants = type { <4 x float>, %struct.TerrainHeightFieldParameters, [5 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], %struct.TerrainColorParameters, [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, [4 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], <4 x float>, <4 x float>, <4 x float>, <4 x float>, <4 x float>, [120 x <4 x float>], [4 x <4 x float>], [8 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], %struct.TerrainVirtualTexureParameters, [7 x <4 x float>], [4 x <4 x float>], <4 x float>, [4 x <4 x float>], <4 x float>, [4 x <4 x float>], [4 x <4 x float>], [8 x <4 x float>], [4 x <4 x float>], [4 x <4 x float>], [3 x <4 x float>], [5 x <4 x float>], [4 x <4 x float>], <4 x float>, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, i32, <3 x float>, float, <3 x float>, float, <3 x float>, float, <3 x float>, float, <3 x float>, i32, <3 x float>, float, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, <2 x float>, i32, i32, float, i32, i32, i32, i32, float, i32, float, i32, i32, float, float, float, i32, float, i32, float, float, float, float, i32, float, i32, i32, i32, i32, i32, float, float, i32, i32, i32, i32, i32 }
%struct.TerrainHeightFieldParameters = type { <4 x float>, <4 x float>, <4 x float>, <2 x i32>, float, float }
%struct.TerrainColorParameters = type { <4 x float>, <3 x float>, float }
%struct.TerrainVirtualTexureParameters = type { <4 x float>, <2 x i32>, i32, i32, <4 x float>, i32, <3 x float> }
%struct.SamplerState = type { i32 }

@.hca.1 = internal unnamed_addr constant [16 x float] [float 1.000000e+00, float 1.000000e+00, float 0.000000e+00, float 0x3FA6F163A0000000, float 0.000000e+00, float 0x3FE59041E0000000, float 1.000000e+00, float 0.000000e+00, float 0.000000e+00, float 0.000000e+00, float 0x3FE4E89740000000, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00]

define void @ShaderDomain_Ps() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 6, i32 36, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 5, i32 35, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 4, i32 2, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %4 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 3, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %5 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 2, i32 33, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %6 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %7 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 32, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %8 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 3, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %9 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 2, i32 1, i32 4, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %10 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 2, i32 0, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %9, i32 267)  ; CBufferLoadLegacy(handle,regIndex)
  %28 = extractvalue %dx.types.CBufRet.f32 %27, 3
  %29 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %9, i32 269)  ; CBufferLoadLegacy(handle,regIndex)
  %30 = extractvalue %dx.types.CBufRet.f32 %29, 3
  %31 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %9, i32 265)  ; CBufferLoadLegacy(handle,regIndex)
  %32 = extractvalue %dx.types.CBufRet.f32 %31, 0
  %33 = extractvalue %dx.types.CBufRet.f32 %31, 1
  %34 = extractvalue %dx.types.CBufRet.f32 %31, 2
  %35 = fsub fast float %32, %23
  %36 = fsub fast float %33, %24
  %37 = fsub fast float %34, %25
  %38 = call float @dx.op.dot3.f32(i32 55, float %35, float %36, float %37, float %35, float %36, float %37)  ; Dot3(ax,ay,az,bx,by,bz)
  %39 = call float @dx.op.unary.f32(i32 25, float %38)  ; Rsqrt(value)
  %40 = fmul fast float %35, %39
  %41 = fmul fast float %36, %39
  %42 = fmul fast float %37, %39
  %43 = call float @dx.op.unary.f32(i32 27, float %22)  ; Round_ni(value)
  %44 = fptosi float %43 to i32
  %45 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %10, i32 2)  ; CBufferLoadLegacy(handle,regIndex)
  %46 = extractvalue %dx.types.CBufRet.i32 %45, 3
  %47 = icmp eq i32 %44, %46
  %48 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %10, i32 4)  ; CBufferLoadLegacy(handle,regIndex)
  %49 = extractvalue %dx.types.CBufRet.i32 %48, 3
  %50 = icmp ne i32 %49, 0
  %51 = and i1 %47, %50
  %52 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %10, i32 4)  ; CBufferLoadLegacy(handle,regIndex)
  %53 = extractvalue %dx.types.CBufRet.f32 %52, 0
  %54 = extractvalue %dx.types.CBufRet.f32 %52, 1
  %55 = fmul fast float %53, %14
  %56 = fmul fast float %54, %18
  %57 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %2, %dx.types.Handle %8, float %55, float %56, float undef, float undef, i32 0, i32 0, i32 undef, float %28, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %58 = extractvalue %dx.types.ResRet.f32 %57, 0
  %59 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %1, %dx.types.Handle %8, float %55, float %56, float undef, float undef, i32 0, i32 0, i32 undef, float %28, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %60 = extractvalue %dx.types.ResRet.f32 %59, 0
  %61 = extractvalue %dx.types.ResRet.f32 %59, 1
  %62 = fmul fast float %60, 2.000000e+00
  %63 = fmul fast float %61, 2.000000e+00
  %64 = fadd fast float %62, -1.000000e+00
  %65 = fadd fast float %63, -1.000000e+00
  %66 = fmul fast float %64, %64
  %67 = fmul fast float %65, %65
  %68 = fsub fast float 1.000000e+00, %67
  %69 = fsub fast float %68, %66
  %70 = call float @dx.op.unary.f32(i32 7, float %69)  ; Saturate(value)
  %71 = call float @dx.op.unary.f32(i32 24, float %70)  ; Sqrt(value)
  %72 = call float @dx.op.unary.f32(i32 22, float %22)  ; Frc(value)
  %73 = call float @dx.op.unary.f32(i32 22, float %26)  ; Frc(value)
  %74 = call float @dx.op.binary.f32(i32 35, float %72, float 0.000000e+00)  ; FMax(a,b)
  %75 = call float @dx.op.binary.f32(i32 35, float %73, float 0.000000e+00)  ; FMax(a,b)
  %76 = call float @dx.op.binary.f32(i32 36, float %74, float 1.000000e+00)  ; FMin(a,b)
  %77 = call float @dx.op.binary.f32(i32 36, float %75, float 1.000000e+00)  ; FMin(a,b)
  %78 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %3, %dx.types.Handle %8, float %76, float %77, float undef, float undef, i32 0, i32 0, i32 undef, float %28, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %79 = extractvalue %dx.types.ResRet.f32 %78, 0
  %80 = extractvalue %dx.types.ResRet.f32 %78, 2
  br i1 %51, label %81, label %117

; <label>:81                                      ; preds = %0
  %82 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %4, %dx.types.Handle %8, float %76, float %77, float undef, float undef, i32 0, i32 0, i32 undef, float %28, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %83 = extractvalue %dx.types.ResRet.f32 %82, 0
  %84 = extractvalue %dx.types.ResRet.f32 %82, 1
  %85 = fmul fast float %83, 2.000000e+00
  %86 = fmul fast float %84, 2.000000e+00
  %87 = fadd fast float %85, -1.000000e+00
  %88 = fadd fast float %86, -1.000000e+00
  %89 = fmul fast float %87, %87
  %90 = fmul fast float %88, %88
  %91 = fsub fast float 1.000000e+00, %90
  %92 = fsub fast float %91, %89
  %93 = call float @dx.op.unary.f32(i32 7, float %92)  ; Saturate(value)
  %94 = call float @dx.op.unary.f32(i32 24, float %93)  ; Sqrt(value)
  %95 = fadd fast float %80, 0xBFB99999A0000000
  %96 = fmul fast float %95, 0x3FF1C71C80000000
  %97 = call float @dx.op.unary.f32(i32 7, float %96)  ; Saturate(value)
  %98 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %10, i32 4)  ; CBufferLoadLegacy(handle,regIndex)
  %99 = extractvalue %dx.types.CBufRet.f32 %98, 2
  %100 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %10, i32 3)  ; CBufferLoadLegacy(handle,regIndex)
  %101 = extractvalue %dx.types.CBufRet.f32 %100, 3
  %102 = fsub fast float %99, %101
  %103 = fmul fast float %102, %97
  %104 = fsub fast float %87, %64
  %105 = fsub fast float %88, %65
  %106 = fsub fast float %94, %71
  %107 = fmul fast float %104, %79
  %108 = fmul fast float %105, %79
  %109 = fmul fast float %106, %79
  %110 = fadd fast float %107, %64
  %111 = fadd fast float %108, %65
  %112 = fadd fast float %109, %71
  %113 = fsub fast float %101, %58
  %114 = fadd fast float %113, %103
  %115 = fmul fast float %114, %79
  %116 = fadd fast float %115, %58
  br label %117

; <label>:117                                     ; preds = %81, %0
  %118 = phi float [ %116, %81 ], [ %58, %0 ]
  %119 = phi float [ %110, %81 ], [ %64, %0 ]
  %120 = phi float [ %111, %81 ], [ %65, %0 ]
  %121 = phi float [ %112, %81 ], [ %71, %0 ]
  %122 = fmul fast float %119, %19
  %123 = call float @dx.op.tertiary.f32(i32 46, float %120, float %15, float %122)  ; FMad(a,b,c)
  %124 = call float @dx.op.tertiary.f32(i32 46, float %121, float %11, float %123)  ; FMad(a,b,c)
  %125 = fmul fast float %119, %20
  %126 = call float @dx.op.tertiary.f32(i32 46, float %120, float %16, float %125)  ; FMad(a,b,c)
  %127 = call float @dx.op.tertiary.f32(i32 46, float %121, float %12, float %126)  ; FMad(a,b,c)
  %128 = fmul fast float %119, %21
  %129 = call float @dx.op.tertiary.f32(i32 46, float %120, float %17, float %128)  ; FMad(a,b,c)
  %130 = call float @dx.op.tertiary.f32(i32 46, float %121, float %13, float %129)  ; FMad(a,b,c)
  %131 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %10, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %132 = extractvalue %dx.types.CBufRet.i32 %131, 3
  switch i32 %132, label %136 [
    i32 0, label %137
    i32 1, label %137
    i32 2, label %133
    i32 3, label %134
    i32 4, label %135
  ]

; <label>:133                                     ; preds = %117
  br label %137

; <label>:134                                     ; preds = %117
  br label %137

; <label>:135                                     ; preds = %117
  br label %137

; <label>:136                                     ; preds = %117
  br label %137

; <label>:137                                     ; preds = %136, %135, %134, %133, %117, %117
  %138 = phi float [ 0.000000e+00, %136 ], [ 2.000000e+00, %135 ], [ 2.000000e+00, %134 ], [ 0x3FD3333340000000, %133 ], [ 4.000000e+00, %117 ], [ 4.000000e+00, %117 ]
  %139 = fmul fast float %138, %22
  %140 = fmul fast float %138, %26
  %141 = fmul fast float %140, 4.000000e+00
  switch i32 %132, label %144 [
    i32 1, label %145
    i32 2, label %142
    i32 3, label %145
    i32 4, label %143
  ]

; <label>:142                                     ; preds = %137
  br label %145

; <label>:143                                     ; preds = %137
  br label %145

; <label>:144                                     ; preds = %137
  br label %145

; <label>:145                                     ; preds = %144, %143, %142, %137, %137
  %146 = phi float [ 0.000000e+00, %144 ], [ 5.000000e+00, %143 ], [ 3.000000e+00, %142 ], [ 1.000000e+00, %137 ], [ 1.000000e+00, %137 ]
  %147 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %7, %dx.types.Handle %8, float %139, float %141, float %146, float undef, i32 0, i32 0, i32 undef, float %28, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %148 = extractvalue %dx.types.ResRet.f32 %147, 0
  %149 = extractvalue %dx.types.ResRet.f32 %147, 1
  %150 = extractvalue %dx.types.ResRet.f32 %147, 2
  %151 = fmul fast float %139, 5.000000e-01
  %152 = fmul fast float %140, 2.000000e+00
  %153 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %10, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %154 = extractvalue %dx.types.CBufRet.i32 %153, 3
  switch i32 %154, label %157 [
    i32 0, label %158
    i32 1, label %155
    i32 2, label %158
    i32 3, label %156
    i32 4, label %158
  ]

; <label>:155                                     ; preds = %145
  br label %158

; <label>:156                                     ; preds = %145
  br label %158

; <label>:157                                     ; preds = %145
  br label %158

; <label>:158                                     ; preds = %157, %156, %155, %145, %145, %145
  %159 = phi float [ 0.000000e+00, %157 ], [ 4.000000e+00, %156 ], [ 1.000000e+00, %155 ], [ 3.000000e+00, %145 ], [ 3.000000e+00, %145 ], [ 3.000000e+00, %145 ]
  %160 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %7, %dx.types.Handle %8, float %151, float %152, float %159, float undef, i32 0, i32 0, i32 undef, float %28, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %161 = extractvalue %dx.types.ResRet.f32 %160, 0
  %162 = extractvalue %dx.types.ResRet.f32 %160, 1
  %163 = extractvalue %dx.types.ResRet.f32 %160, 2
  %164 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %10, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %165 = extractvalue %dx.types.CBufRet.i32 %164, 3
  switch i32 %165, label %166 [
    i32 0, label %167
    i32 4, label %167
  ]

; <label>:166                                     ; preds = %158
  br label %167

; <label>:167                                     ; preds = %166, %158, %158
  %168 = phi float [ 5.000000e-01, %166 ], [ 2.500000e-01, %158 ], [ 2.500000e-01, %158 ]
  %169 = fsub fast float %161, %148
  %170 = fsub fast float %162, %149
  %171 = fsub fast float %163, %150
  %172 = fmul fast float %168, %169
  %173 = fmul fast float %168, %170
  %174 = fmul fast float %168, %171
  %175 = fadd fast float %148, -5.000000e-01
  %176 = fadd fast float %175, %172
  %177 = fadd fast float %149, -5.000000e-01
  %178 = fadd fast float %177, %173
  %179 = fadd fast float %150, -5.000000e-01
  %180 = fadd fast float %179, %174
  switch i32 %165, label %184 [
    i32 0, label %185
    i32 1, label %181
    i32 2, label %185
    i32 3, label %182
    i32 4, label %183
  ]

; <label>:181                                     ; preds = %167
  br label %185

; <label>:182                                     ; preds = %167
  br label %185

; <label>:183                                     ; preds = %167
  br label %185

; <label>:184                                     ; preds = %167
  br label %185

; <label>:185                                     ; preds = %184, %183, %182, %181, %167, %167
  %186 = phi float [ 0.000000e+00, %184 ], [ 0x3FD3333340000000, %183 ], [ 1.000000e+00, %182 ], [ 5.000000e-01, %181 ], [ 2.500000e-01, %167 ], [ 2.500000e-01, %167 ]
  %187 = fmul fast float %186, %176
  %188 = fmul fast float %186, %178
  %189 = fmul fast float %186, %180
  %190 = fadd fast float %187, %124
  %191 = fadd fast float %188, %127
  %192 = fadd fast float %189, %130
  %193 = fcmp fast oeq float %190, 0.000000e+00
  %194 = fcmp fast oeq float %191, 0.000000e+00
  %195 = fcmp fast oeq float %192, 0.000000e+00
  %196 = and i1 %193, %194
  %197 = and i1 %195, %196
  br i1 %197, label %204, label %198

; <label>:198                                     ; preds = %185
  %199 = call float @dx.op.dot3.f32(i32 55, float %190, float %191, float %192, float %190, float %191, float %192)  ; Dot3(ax,ay,az,bx,by,bz)
  %200 = call float @dx.op.unary.f32(i32 25, float %199)  ; Rsqrt(value)
  %201 = fmul fast float %200, %190
  %202 = fmul fast float %200, %191
  %203 = fmul fast float %200, %192
  br label %204

; <label>:204                                     ; preds = %198, %185
  %205 = phi float [ %201, %198 ], [ 0.000000e+00, %185 ]
  %206 = phi float [ %202, %198 ], [ 0.000000e+00, %185 ]
  %207 = phi float [ %203, %198 ], [ 0.000000e+00, %185 ]
  %208 = call float @dx.op.dot3.f32(i32 55, float %40, float %41, float %42, float %205, float %206, float %207)  ; Dot3(ax,ay,az,bx,by,bz)
  %209 = fmul fast float %208, 2.000000e+00
  %210 = fmul fast float %209, %205
  %211 = fmul fast float %209, %206
  %212 = fmul fast float %209, %207
  %213 = fsub fast float %40, %210
  %214 = fsub fast float %41, %211
  %215 = fsub fast float %42, %212
  %216 = fdiv fast float %213, %215
  %217 = call float @dx.op.unary.f32(i32 17, float %216)  ; Atan(value)
  %218 = fadd fast float %217, 0x400921FB60000000
  %219 = fadd fast float %217, 0xC00921FB60000000
  %220 = fcmp fast olt float %215, 0.000000e+00
  %221 = fcmp fast oeq float %215, 0.000000e+00
  %222 = fcmp fast oge float %213, 0.000000e+00
  %223 = fcmp fast olt float %213, 0.000000e+00
  %224 = and i1 %220, %222
  %225 = select i1 %224, float %218, float %217
  %226 = and i1 %220, %223
  %227 = select i1 %226, float %219, float %225
  %228 = and i1 %221, %223
  %229 = and i1 %221, %222
  %230 = fadd fast float %227, 0x400921FB60000000
  %231 = fsub fast float -0.000000e+00, %214
  %232 = call float @dx.op.unary.f32(i32 15, float %231)  ; Acos(value)
  %233 = fmul fast float %230, 0x3FC45F3060000000
  %234 = select i1 %228, float 2.500000e-01, float %233
  %235 = select i1 %229, float 7.500000e-01, float %234
  %236 = fmul fast float %232, 0x3FD45F3060000000
  %237 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %5, %dx.types.Handle %8, float %235, float %236, float undef, float undef, i32 0, i32 0, i32 undef, float %28, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %238 = extractvalue %dx.types.ResRet.f32 %237, 0
  %239 = extractvalue %dx.types.ResRet.f32 %237, 1
  %240 = extractvalue %dx.types.ResRet.f32 %237, 2
  %241 = call float @dx.op.dot3.f32(i32 55, float %238, float %239, float %240, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot3(ax,ay,az,bx,by,bz)
  %242 = call float @dx.op.unary.f32(i32 23, float %241)  ; Log(value)
  %243 = fmul fast float %242, 4.000000e+00
  %244 = call float @dx.op.unary.f32(i32 21, float %243)  ; Exp(value)
  %245 = call %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32 59, %dx.types.Handle %10, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %246 = extractvalue %dx.types.CBufRet.i32 %245, 3
  %247 = add i32 %246, -1
  %248 = icmp ult i32 %247, 4
  br i1 %248, label %249, label %254

; <label>:249                                     ; preds = %204
  %250 = trunc i32 %247 to i4
  %251 = lshr i4 -3, %250
  %252 = and i4 %251, 1
  %253 = icmp ne i4 %252, 0
  br label %254

; <label>:254                                     ; preds = %249, %204
  %255 = phi i1 [ %253, %249 ], [ false, %204 ]
  br i1 %255, label %256, label %264

; <label>:256                                     ; preds = %254
  %257 = fmul fast float %208, 1.000000e+01
  %258 = call float @dx.op.unary.f32(i32 26, float %257)  ; Round_ne(value)
  %259 = fmul fast float %258, 0x3FB99999A0000000
  %260 = call float @dx.op.unary.f32(i32 13, float %259)  ; Sin(value)
  %261 = fadd fast float %260, -7.500000e-01
  %262 = fmul fast float %261, 5.000000e+00
  %263 = fadd fast float %262, 7.500000e-01
  br label %269

; <label>:264                                     ; preds = %254
  %265 = call float @dx.op.unary.f32(i32 13, float %208)  ; Sin(value)
  %266 = fadd fast float %265, 0xBFE99999A0000000
  %267 = fmul fast float %266, 8.000000e+00
  %268 = fadd fast float %267, 0x3FE99999A0000000
  br label %269

; <label>:269                                     ; preds = %264, %256
  %270 = phi float [ %263, %256 ], [ %268, %264 ]
  %271 = call float @dx.op.binary.f32(i32 35, float %270, float 0.000000e+00)  ; FMax(a,b)
  %272 = call float @dx.op.binary.f32(i32 36, float %271, float 1.000000e+00)  ; FMin(a,b)
  %273 = fmul fast float %272, 3.000000e+00
  %274 = call float @dx.op.unary.f32(i32 22, float %273)  ; Frc(value)
  %275 = fptoui float %273 to i32
  %276 = call i32 @dx.op.binary.i32(i32 40, i32 %275, i32 3)  ; UMin(a,b)
  %277 = add i32 %276, 1
  %278 = call i32 @dx.op.binary.i32(i32 40, i32 %277, i32 3)  ; UMin(a,b)
  %279 = add i32 %276, 4
  %280 = add i32 %276, 8
  %281 = getelementptr [16 x float], [16 x float]* @.hca.1, i32 0, i32 %276
  %282 = load float, float* %281, align 4
  %283 = getelementptr [16 x float], [16 x float]* @.hca.1, i32 0, i32 %279
  %284 = load float, float* %283, align 4
  %285 = getelementptr [16 x float], [16 x float]* @.hca.1, i32 0, i32 %280
  %286 = load float, float* %285, align 4
  %287 = add i32 %278, 4
  %288 = add i32 %278, 8
  %289 = getelementptr [16 x float], [16 x float]* @.hca.1, i32 0, i32 %278
  %290 = load float, float* %289, align 4
  %291 = getelementptr [16 x float], [16 x float]* @.hca.1, i32 0, i32 %287
  %292 = load float, float* %291, align 4
  %293 = getelementptr [16 x float], [16 x float]* @.hca.1, i32 0, i32 %288
  %294 = load float, float* %293, align 4
  %295 = fsub fast float %290, %282
  %296 = fsub fast float %292, %284
  %297 = fsub fast float %294, %286
  %298 = fmul fast float %295, %274
  %299 = fmul fast float %296, %274
  %300 = fmul fast float %297, %274
  %301 = fadd fast float %298, %282
  %302 = fadd fast float %299, %284
  %303 = fadd fast float %300, %286
  %304 = fmul fast float %270, 5.000000e+00
  %305 = call float @dx.op.unary.f32(i32 7, float %304)  ; Saturate(value)
  %306 = fmul fast float %305, 2.000000e+00
  %307 = fsub fast float 3.000000e+00, %306
  %308 = fadd fast float %270, -1.000000e+00
  %309 = fmul fast float %308, 0xC013FFFFC0000000
  %310 = call float @dx.op.unary.f32(i32 7, float %309)  ; Saturate(value)
  %311 = fmul fast float %310, 2.000000e+00
  %312 = fsub fast float 3.000000e+00, %311
  %313 = fmul float %305, %310
  %314 = fmul float %313, %313
  %315 = fmul fast float %312, %307
  %316 = fmul fast float %315, %314
  %317 = fadd fast float %316, %244
  %318 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %10, i32 1)  ; CBufferLoadLegacy(handle,regIndex)
  %319 = extractvalue %dx.types.CBufRet.f32 %318, 3
  %320 = fmul fast float %317, %319
  %321 = fmul fast float %180, %41
  %322 = fmul fast float %178, %42
  %323 = fsub fast float %321, %322
  %324 = fmul fast float %176, %42
  %325 = fmul fast float %180, %40
  %326 = fsub fast float %324, %325
  %327 = fmul fast float %178, %40
  %328 = fmul fast float %176, %41
  %329 = fsub fast float %327, %328
  %330 = fmul fast float %326, %180
  %331 = fmul fast float %329, %178
  %332 = fsub fast float %330, %331
  %333 = fmul fast float %329, %176
  %334 = fmul fast float %323, %180
  %335 = fsub fast float %333, %334
  %336 = fmul fast float %323, %178
  %337 = fmul fast float %326, %176
  %338 = fsub fast float %336, %337
  %339 = fsub fast float -0.000000e+00, %332
  %340 = fsub fast float -0.000000e+00, %335
  %341 = fsub fast float -0.000000e+00, %338
  %342 = fcmp oeq float %332, -0.000000e+00
  %343 = fcmp oeq float %335, -0.000000e+00
  %344 = fcmp oeq float %338, -0.000000e+00
  %345 = and i1 %342, %343
  %346 = and i1 %344, %345
  br i1 %346, label %356, label %347

; <label>:347                                     ; preds = %269
  %348 = call float @dx.op.dot3.f32(i32 55, float %339, float %340, float %341, float %339, float %340, float %341)  ; Dot3(ax,ay,az,bx,by,bz)
  %349 = call float @dx.op.unary.f32(i32 25, float %348)  ; Rsqrt(value)
  %350 = fmul fast float %349, %339
  %351 = fmul fast float %349, %340
  %352 = fmul fast float %349, %341
  %353 = fsub float -0.000000e+00, %350
  %354 = fsub float -0.000000e+00, %351
  %355 = fsub float -0.000000e+00, %352
  br label %356

; <label>:356                                     ; preds = %347, %269
  %357 = phi float [ %353, %347 ], [ -0.000000e+00, %269 ]
  %358 = phi float [ %354, %347 ], [ -0.000000e+00, %269 ]
  %359 = phi float [ %355, %347 ], [ -0.000000e+00, %269 ]
  %360 = call float @dx.op.dot3.f32(i32 55, float %357, float %358, float %359, float %40, float %41, float %42)  ; Dot3(ax,ay,az,bx,by,bz)
  %361 = call float @dx.op.unary.f32(i32 6, float %360)  ; FAbs(value)
  %362 = call float @dx.op.unary.f32(i32 23, float %361)  ; Log(value)
  %363 = fmul fast float %362, 1.200000e+01
  %364 = call float @dx.op.unary.f32(i32 21, float %363)  ; Exp(value)
  %365 = fadd fast float %364, %320
  %366 = fmul fast float %365, %301
  %367 = fmul fast float %365, %302
  %368 = fmul fast float %365, %303
  %369 = call float @dx.op.dot3.f32(i32 55, float %366, float %367, float %368, float 0x3FD5554760000000, float 0x3FD5554760000000, float 0x3FD5554760000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %370 = fmul fast float %80, 1.000000e+01
  %371 = call float @dx.op.unary.f32(i32 7, float %370)  ; Saturate(value)
  %372 = fsub fast float 1.000000e+00, %371
  %373 = call float @dx.op.binary.f32(i32 35, float %118, float %372)  ; FMax(a,b)
  %374 = fsub fast float %369, %366
  %375 = fsub fast float %369, %367
  %376 = fsub fast float %369, %368
  %377 = fmul fast float %373, %374
  %378 = fmul fast float %373, %375
  %379 = fmul fast float %373, %376
  %380 = fadd fast float %377, %366
  %381 = fadd fast float %378, %367
  %382 = fadd fast float %379, %368
  %383 = call %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32 59, %dx.types.Handle %10, i32 0)  ; CBufferLoadLegacy(handle,regIndex)
  %384 = extractvalue %dx.types.CBufRet.f32 %383, 0
  %385 = extractvalue %dx.types.CBufRet.f32 %383, 1
  %386 = extractvalue %dx.types.CBufRet.f32 %383, 2
  %387 = fmul fast float %384, %380
  %388 = fmul fast float %385, %381
  %389 = fmul fast float %386, %382
  %390 = call float @dx.op.unary.f32(i32 7, float %387)  ; Saturate(value)
  %391 = call float @dx.op.unary.f32(i32 7, float %388)  ; Saturate(value)
  %392 = call float @dx.op.unary.f32(i32 7, float %389)  ; Saturate(value)
  %393 = call float @dx.op.unary.f32(i32 23, float %390)  ; Log(value)
  %394 = call float @dx.op.unary.f32(i32 23, float %391)  ; Log(value)
  %395 = call float @dx.op.unary.f32(i32 23, float %392)  ; Log(value)
  %396 = fmul fast float %393, 4.000000e+00
  %397 = fmul fast float %394, 4.000000e+00
  %398 = fmul fast float %395, 4.000000e+00
  %399 = call float @dx.op.unary.f32(i32 21, float %396)  ; Exp(value)
  %400 = call float @dx.op.unary.f32(i32 21, float %397)  ; Exp(value)
  %401 = call float @dx.op.unary.f32(i32 21, float %398)  ; Exp(value)
  %402 = call %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32 61, %dx.types.Handle %6, %dx.types.Handle %8, float %22, float %26, float undef, float undef, i32 0, i32 0, i32 undef, float %28, float undef)  ; SampleBias(srv,sampler,coord0,coord1,coord2,coord3,offset0,offset1,offset2,bias,clamp)
  %403 = extractvalue %dx.types.ResRet.f32 %402, 0
  %404 = call float @dx.op.dot3.f32(i32 55, float %124, float %127, float %130, float %40, float %41, float %42)  ; Dot3(ax,ay,az,bx,by,bz)
  %405 = call float @dx.op.unary.f32(i32 7, float %404)  ; Saturate(value)
  %406 = fmul fast float %403, 2.000000e+00
  %407 = fmul fast float %405, %405
  %408 = fmul fast float %407, %406
  %409 = call float @dx.op.unary.f32(i32 7, float %408)  ; Saturate(value)
  %410 = fmul fast float %409, %371
  %411 = fmul fast float %30, 1.000000e+03
  %412 = fmul fast float %410, %411
  %413 = fmul fast float %412, %399
  %414 = fmul fast float %412, %400
  %415 = fmul fast float %412, %401
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %413)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %414)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %415)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float 0.000000e+00)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.sampleBias.f32(i32, %dx.types.Handle, %dx.types.Handle, float, float, float, float, i32, i32, i32, float, float) #2

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.CBufRet.i32 @dx.op.cbufferLoadLegacy.i32(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.CBufRet.f32 @dx.op.cbufferLoadLegacy.f32(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!19}
!dx.entryPoints = !{!20}

!0 = !{!"dxcoob 1.8.2505.0"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 10}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, !14, !17}
!5 = !{!6, !8, !9, !10, !11, !12, !13}
!6 = !{i32 0, %"class.Texture2DArray<vector<float, 4> >"* undef, !"", i32 0, i32 32, i32 1, i32 7, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!9 = !{i32 2, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 33, i32 1, i32 2, i32 0, !7}
!10 = !{i32 3, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!11 = !{i32 4, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 2, i32 1, i32 2, i32 0, !7}
!12 = !{i32 5, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 35, i32 1, i32 2, i32 0, !7}
!13 = !{i32 6, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 36, i32 1, i32 2, i32 0, !7}
!14 = !{!15, !16}
!15 = !{i32 0, %PerObjectImmutableConstants* undef, !"", i32 0, i32 1, i32 1, i32 80, null}
!16 = !{i32 1, %hostlayout.PerPassConstants* undef, !"", i32 0, i32 4, i32 1, i32 4552, null}
!17 = !{!18}
!18 = !{i32 0, %struct.SamplerState* undef, !"", i32 0, i32 0, i32 1, i32 0, null}
!19 = !{[22 x i32] [i32 20, i32 4, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0]}
!20 = !{void ()* @ShaderDomain_Ps, !"ShaderDomain_Ps", !21, !4, null}
!21 = !{!22, !33, null}
!22 = !{!23, !26, !28, !30, !32}
!23 = !{i32 0, !"TEXCOORD", i8 9, i8 0, !24, i8 2, i32 1, i8 4, i32 0, i8 0, !25}
!24 = !{i32 0}
!25 = !{i32 3, i32 15}
!26 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !27, i8 2, i32 1, i8 4, i32 1, i8 0, !25}
!27 = !{i32 1}
!28 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !29, i8 2, i32 1, i8 4, i32 2, i8 0, !25}
!29 = !{i32 2}
!30 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !31, i8 2, i32 1, i8 4, i32 3, i8 0, !25}
!31 = !{i32 3}
!32 = !{i32 4, !"SV_Position", i8 9, i8 3, !24, i8 4, i32 1, i8 4, i32 4, i8 0, null}
!33 = !{!34}
!34 = !{i32 0, !"SV_Target", i8 9, i8 16, !24, i8 0, i32 1, i8 4, i32 0, i8 0, !25}

